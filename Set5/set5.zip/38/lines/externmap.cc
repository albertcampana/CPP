#include "lines.ih"
                        // map that saves the vector of each Lines object
map<Lines const *, vector<string>> LinesMap;
