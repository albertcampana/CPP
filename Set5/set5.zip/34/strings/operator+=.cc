#include "strings.ih"
void Strings::operator+=(string str)
{
    push_back(str);
}
