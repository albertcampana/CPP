#include "vectorString.ih"

void VectorString::swap(VectorString &other)
{
    uniqueWordsVector.swap(other.uniqueWordsVector);     // Swap vectors
}
