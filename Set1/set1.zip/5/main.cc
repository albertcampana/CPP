#include "first.hh"
#include "second.hh"

int main()
{
    fun(First::Enum{});
}
