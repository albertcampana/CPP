#include "first.ih"

void First::fun(First::Enum symbol)
{
    std::cout << "First::fun() called \n";
}
