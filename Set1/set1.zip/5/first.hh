namespace First
{
    enum Enum
    {};
    
    void fun(Enum symbol);
}
