namespace Second
{    
    void fun(First::Enum symbol);
}
