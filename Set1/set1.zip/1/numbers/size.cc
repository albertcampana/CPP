#include "numbers.ih"

size_t const Numbers::size() const
{
    return d_size;
}
