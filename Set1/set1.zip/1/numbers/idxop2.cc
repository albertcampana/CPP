#include "numbers.ih"

int Numbers::operator[](size_t index) const
{
    return operatorIndex(index);
}
