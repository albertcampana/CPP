#include "main.ih"

Base::~Base()
{}