#include "main.ih"

Derived::~Derived()
{}