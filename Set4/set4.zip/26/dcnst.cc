#include "main.ih"

Derived::Derived()
{
    d_text = "hello from Derived";
}