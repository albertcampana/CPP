#include "main.ih"

void Base::hello(std::ostream &out)
{
    vHello(out);
}