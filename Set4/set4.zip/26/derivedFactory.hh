Base **derivedFactory(size_t size);
