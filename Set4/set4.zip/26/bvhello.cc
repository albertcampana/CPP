#include "main.ih"

void Base::vHello(std::ostream &out)
{
    out << "Hello from Base\n";
}