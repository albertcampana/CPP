class Basic
{
    public:
        Basic();
        Basic(int value);
};
