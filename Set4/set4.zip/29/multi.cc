#include "main.ih"

Multi::Multi()
:
    Deriv1()
{
    cout << static_cast<Basic *>(this) << '\n';
}
