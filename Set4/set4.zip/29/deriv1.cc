#include "main.ih"

Deriv1::Deriv1()
:
    Basic(7)
{}
