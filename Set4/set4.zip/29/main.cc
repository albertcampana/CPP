#include "main.ih"

int main()
{
    Multi multi;
    Deriv1 deriv1;
}
