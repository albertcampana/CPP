class Deriv1 : public virtual Basic
{
    public:
        Deriv1();
};
