class Multi : public Deriv1, public Deriv2
{
    public:
        Multi();
};
