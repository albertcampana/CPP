#include "main.ih"

Basic::Basic()
{
    cout << "Basic() constructor called \n";
}

Basic::Basic(int value)
{
    cout << "Basic(int) constructor called \n";
}
