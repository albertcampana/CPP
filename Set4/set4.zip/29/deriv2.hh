class Deriv2 : public virtual Basic
{};
