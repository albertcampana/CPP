class Handler : private Base
{
    public:
        Handler();
};
