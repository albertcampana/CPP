class Processor : private Base
{
    public:
        Processor();
};
