#include "show.hh"

Handler::Handler()
{
    show(Msg::NONE | Msg::EMERG);
}

