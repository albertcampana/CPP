#include "show.hh"

Processor::Processor()
{
    show(Msg::NONE | Msg::EMERG);
}

