#include "main.ih"

void show(Base::Msg msg);
