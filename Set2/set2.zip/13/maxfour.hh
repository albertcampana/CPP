#ifndef INCLUDED_MAXFOUR_H_
#define INCLUDED_MAXFOUR_H_

#include <cstddef>

class MaxFour
{
    static size_t s_n0bjects;
    
    public:
        MaxFour();
        ~MaxFour() = default;
};

#endif
