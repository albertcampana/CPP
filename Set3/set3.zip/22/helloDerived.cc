#include "main.ih"

void Derived::hello()
{
    cout << "Derived: hello...\n";
}
