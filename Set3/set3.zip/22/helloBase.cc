#include "main.ih"

void Base::hello()
{
    cout << "Base: hello...\n";
}
