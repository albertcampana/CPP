#include "main.ih"

Base::Base()
{
    cout << "Base constructor\n";
}

void Base::hello()
{
    cout << "Base: hello...\n";
}
