class Base
{
    public:
        Base();
        virtual void hello();
};
