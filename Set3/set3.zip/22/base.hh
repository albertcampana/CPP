class Base
{
    public:
        Base();
        void hello();
};
