void caller(Base &obj);
