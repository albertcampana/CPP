#include "main.ih"

Base::Base()
{
    cout << "Base constructor\n";
}
