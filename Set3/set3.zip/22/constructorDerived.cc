#include "main.ih"

Derived::Derived()
{
    cout << "Derived constructor\n";
}
