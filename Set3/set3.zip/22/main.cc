#include "main.ih"

int main()
{
    Derived derived;
    caller(derived);
}
