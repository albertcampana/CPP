class Derived : public Base
{
    std::string derived_d;
    
    public:
        Derived();
        void hello();
};
