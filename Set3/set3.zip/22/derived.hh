class Derived : public Base
{
    public:
        Derived();
        void hello();
};
