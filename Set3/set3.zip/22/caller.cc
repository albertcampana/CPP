#include "main.ih"

void caller(Base &obj)
{
    obj.hello();
}
