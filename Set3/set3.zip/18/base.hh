class Base
{
    public:
        Base();
        Base(Base const &other);
        Base(Base &&tmp);
};
