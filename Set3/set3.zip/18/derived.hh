class Derived : public Base
{};
